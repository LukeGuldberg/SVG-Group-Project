// Luke
#pragma once 

#include <string> 
//sets the default properties for each element
struct Properties {
    std::string stroke{"black"};
    std::string fill {"black"};
    double opacity {1.0};
};