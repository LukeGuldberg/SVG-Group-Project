// Sam Sutton & Alyssa Ebeling
#pragma once
// all coordinates use this structure
struct Point {
    double x;
    double y;
};